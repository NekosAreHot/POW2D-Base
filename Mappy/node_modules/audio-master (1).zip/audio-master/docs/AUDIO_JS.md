## Audio.js Framework
Audio.js is a framework of utilities used for audio creation and manipulation inside of JavaScript.  The `Audio` object (this repository) is the core of the framework, which most (if not all) of the utilities have some relation to.

You can browse the ["audiojs" keyword on npm][npm-audiojs] to find a collection of utilities from this organization and other people, or you can [create your own](WRITING_UTILS.md).

[npm-audiojs]: https://www.npmjs.com/browse/keyword/audiojs
